#!/bin/bash
#SBATCH --job-name=test_PAMM                   # Job Name
#SBATCH -o test.o%j                # Output file name (%j expands to jobID)
#SBATCH -e test.e%j                # Error file name (%j expands to jobID)
#SBATCH --nodes=2                      # Requesting 1 node
#SBATCH --ntasks=64                      # and 16 tasks
#SBATCH --partition=short                  # Queue name (normal, skx-normal, etc.)
#SBATCH -t 24:00:00                # Specify 24 hour run time
#SBATCH --constraint=ib
module load intel/mkl-2021.3.0
module load gcc/10.1.0
module load openmpi/4.1.2-gcc10.1
module load cmake/3.18.1
module load python/3.8.1
module load lammps/29Sep2021_u2-mpi

mpirun -n 64 /shared/centos7/lammps/29Sep2021_u2-mpi/bin/lmp -in test2.in
